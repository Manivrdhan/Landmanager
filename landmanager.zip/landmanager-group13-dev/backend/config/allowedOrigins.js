const allowedOrigins = [
    'https://www.landmanager.com',
    'http://127.0.0.1:5500',
    'http://localhost:5000',
    'http://localhost:3500',
    'http://localhost:3000',
    'http://localhost:5173',
    'https://landmanager-app.netlify.app'
];

module.exports = allowedOrigins;