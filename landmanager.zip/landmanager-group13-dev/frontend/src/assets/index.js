import logo from "./logo.svg"
import Approval from "./Approval.svg"
import close from "./close.svg";
import Heading1 from "./Heading1.svg";
import Line from "./Line.svg"
import Bannerimg from "./Bannerimg.svg";
import FavouritesShield from "./FavoritesShield.svg";
import Recangle from "./Rectangle.svg";
import Group from "./Grouprectangle.svg";
import Project from "./project.svg"
import Step1 from "./step1.svg"
import Step2 from "./step2.svg"
import Step3 from "./step3.svg"
import Alert1 from "./Alert1.svg"
import  Search  from "./search.svg"
import Land from "./LandSurvey.svg"
import Vector from "./Vector.svg"
import Flogo from "./Flogo.svg"
import Footer1 from "./Footer1.svg"
import video from "./VideoCall.svg"
import city from "./City.svg"
import Auction from "./Auction.svg"
import Documents from "./Documents.svg"
import Broom from "./Broom.svg"
import Auctionc from "./Auctionc.svg"
import Spinach from "./Spinach.svg"
import Vest from "./Vest.svg"
import Bolt from "./Bolt.svg"
import Phone from "./phone.svg"
import Approvalp from "./Approvalp.svg"
import click1 from "./click1.svg"
import click2 from "./click2.svg"
import click4 from "./click4.svg"
import click3 from "./click3.svg"

export {
    logo,
    Approval,
    close,
    Heading1,
    Line,
    Bannerimg,
    FavouritesShield,
    Recangle,
    Group,
    Project,
    Step1,
    Step2,
    Step3,
    Alert1,
    Search,
    Land,
    Vector,
    Flogo,
    Footer1,
    video,
    city,
    Auction,
    Documents,
    Broom,
    Auctionc,
    Spinach,
    Vest,
    Bolt,
    Phone,
    Approvalp,
    click1,
    click2,
    click3,
    click4,
}