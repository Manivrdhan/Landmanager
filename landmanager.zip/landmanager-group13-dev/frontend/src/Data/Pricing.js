export default [
    {
        id : "1",
        name : "Security and Monitoring of your plot",
    },
    {
        id : "2",
        name : "Regular visits to plot",
    },
    {
        id : "3",
        name : "Video of plot every quarter",
    },
    {
        id : "4",
        name : "Monthly updates about plot",
    },
    {
        id : "5",
        name : "Market updates",
    },
    {
        id : "6",
        name : "Development updates in & around the plot",
    },
];