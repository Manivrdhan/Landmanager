export default[
    {
        id : "1",
        name : "Is the service paid or free?",
        description : "Paid. Our basic yet amazing package starts at ₹500/mo. You can avail other services too! their prices are not fixed you can negotiate with your LandManager.",
    },
    {
        id : "2",
        name : "Who is a LandManager?",
        description : "A professionally trained agent will be appointed to your land once you register on the app. He/she will be providing regular updates to you. ",
    },
    {
        id : "3",
        name : "How can I contact my LandManager?",
        description : "You can message and call him directly from the app.",
    },
    {
        id : "4",
        name : "How do I register my lands?",
        description : "Simple. Just download the app and you will provided with a button to register your lands.",
    },
];